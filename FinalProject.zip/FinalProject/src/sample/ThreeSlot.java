package sample;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.Timer;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

enum Stop {ONE, TWO, THREE}

public class ThreeSlot extends JFrame implements ActionListener {
	
	private static final long serialVersionUID = 1L;
	
	int currentChip = 0;
	final int MAX = 7;
	Stop iStopCount = Stop.ONE;
	int[] iCount = {1,3,5};
	ArrayList<ImageIcon> SlotImage = new ArrayList<ImageIcon>();
	ArrayList<JLabel> slot = new ArrayList<JLabel>();
	Timer timer;
	JButton[] bt;
	JLabel lbel = new JLabel("Good luck",JLabel.CENTER);
	JLabel chipCalc = new JLabel("Your current chip is: $" + currentChip, JLabel.CENTER);
	JLabel rule = new JLabel("Win $1000 when you get 777");
	JPanel init_Button(String... args) {
		JPanel p = new JPanel();
		bt = new JButton[args.length];
		for (int i = 0; i < args.length; i++) {
			bt[i] = new JButton(args[i]);
			bt[i].setEnabled(false);
			bt[i].addActionListener(this);
			p.add(bt[i]);
		}
		return p;
	}
	
	ThreeSlot(String title, String chipIn) {
		super(title);
		timer = new Timer(300 , this);
		timer.setActionCommand("timer");
		setBounds(500, 500, 500, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Add lbel on the north
		add("North",lbel);
		
		// Add label on the east
		currentChip = Integer.parseInt(chipIn);
		chipCalc.setText("Your current chip is: $" + currentChip);
		JPanel chipInfo = new JPanel(new GridLayout(3,1));
		JLabel chipAmt = new JLabel("Your chip is: $" + chipIn);
		chipInfo.add(chipAmt);
		chipInfo.add(rule);
		chipInfo.add(chipCalc);
		add("East", chipInfo);

		
		// Center panel used to show numbers
		JPanel numberP = new JPanel(new GridLayout(1, 3));
		for(int k = 1;k <= MAX; k++)
			SlotImage.add(new ImageIcon(ThreeSlot.class.getResource("Slot" + k + ".jpg")));
		slot.add(new JLabel(SlotImage.get(0)));
		slot.add(new JLabel(SlotImage.get(0)));
		slot.add(new JLabel(SlotImage.get(0)));
		for(JLabel l : slot) numberP.add(l);
		add("Center",numberP);
		
		// South panel used to show buttons
		add("South",init_Button("Stop","Stop", "Stop", "Start", "Again"));
		bt[3].setEnabled(true);
		
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if(cmd.equals("timer")) {
			int i = 0;
			if(iStopCount == Stop.TWO) i = 1;
			else if(iStopCount == Stop.THREE) i = 2;
			for(; i < iCount.length; i++) {
				if(++iCount[i] == MAX) iCount[i] = 0;
				slot.get(i).setIcon(SlotImage.get(iCount[i]));}
		}

		
		if(e.getSource() == bt[3]) {
			timer.start();
			lbel.setText("Lucky wheel is rolling");
			bt[3].setEnabled(false);
			bt[0].setEnabled(true);
		}
		else if(e.getSource() == bt[0]) {
			iStopCount = Stop.TWO;
			lbel.setText("First lucky number is " + (iCount[0]+1) + ".");
			bt[0].setEnabled(false);
			bt[1].setEnabled(true);
		}
		else if (e.getSource() == bt[1]) {
			iStopCount = Stop.THREE;
			lbel.setText("Second lucky number is " + (iCount[1]+2) + ".");
			if(iCount[0] == iCount[1]) lbel.setText("Second lucky number is " + (iCount[0]+2) + ".");
			bt[1].setEnabled(false);
			bt[2].setEnabled(true);
		}
		else if(e.getSource() == bt[2]) {
			timer.stop();
			lbel.setText("Third lucky number is " + (iCount[2]+3) + ".");
			if(iCount[0] == iCount[1] && iCount[1] == iCount[2]) {
				if(iCount[0] == MAX-1) {
					lbel.setText("You win the prize");
					currentChip=currentChip+1000;
				}
			}
			else {
				lbel.setText("Bad luck. How about try again?");
				currentChip=currentChip-100;
			}
			bt[2].setEnabled(false);
			bt[4].setEnabled(true);
		}
		else if(e.getSource() == bt[4]) {
			// TODO: Scenario when user click again
		}
	}
}