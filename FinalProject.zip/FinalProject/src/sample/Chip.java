package sample;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.Timer;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Chip extends JFrame implements ActionListener {
	
	private String chipIn;

	Chip() {
		super("chip");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		chipIn=JOptionPane.showInputDialog("Insert your chip");
		int jug = Integer.parseInt(chipIn);
		if(jug<100) {
		    JOptionPane.showMessageDialog(null,"Please Insert chip over $100", "Information",JOptionPane.INFORMATION_MESSAGE); 
		    System.exit(-1);
		}
		else{
			JOptionPane.showConfirmDialog(this,"Will you insert $"+chipIn+" chip?","Information",JOptionPane.INFORMATION_MESSAGE);
			setVisible(true);
		}
	}
	
	public String getChipIn() {
		return chipIn;
	}
	
	public void actionPerformed(ActionEvent e) {
		
	}

}
