package sample;

public class Run {

	public static void main(String[] args) {
		Chip cp = new Chip();
		new ThreeSlot("Threeslot",cp.getChipIn());
	}

}